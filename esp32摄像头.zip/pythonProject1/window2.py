# coding:utf-8

import cv2
import numpy as np
import matplotlib.pyplot as plt
print("112")


# 视频流地址
stream_url = 'http://192.168.43.55:81/stream'
print("114")
# 创建一个全零的三维矩阵，形状为 (240, 320, 3)
rgb_zeros_array = np.zeros((240, 320, 3))
print("113")
# 设置字体及字体大小
font = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 0.5
text_color = (255, 255, 255)  # 白色
thickness = 2
line_type = cv2.LINE_AA

# 获取视频流的第一帧以获取视频的宽度和高度
# _, frame = cap.read()
# frame_height, frame_width = frame.shape[:2]
# print("Frame height:", frame_height, "Frame width:", frame_width)



print('0')
while True:
    try:
        # 初始化VideoCapture对象
        cap = cv2.VideoCapture(stream_url)
        print("115")
        # 读取最新的一帧
        ret, frame = cap.read()
        print('1')
        frame_height, frame_width = frame.shape[:2]
        if ret:
            # 计算文字在底部中央的位置
            text_top_left_corner = (int((frame_width - 100) / 2), int(frame_height - 50))

            # 在帧上绘制文字
            cv2.putText(frame, "front", text_top_left_corner, font, font_scale, text_color, thickness, line_type)

            # 显示带有文字的视频帧
            cv2.imshow('Live Video Feed with Text', frame)
        if not ret:
            print(rgb_zeros_array)

            # 将矩阵显示为图像（此处的颜色矩阵会被解释为RGB图像）
            cv2.imshow('stream', rgb_zeros_array)  # 使用'gray'色彩映射以显示灰度图像
    except:
        cv2.imshow('stream', rgb_zeros_array)  # 使用'gray'色彩映射以显示灰度图像

    # 检查按键事件，'q' 键退出循环
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

    # 清理资源
    cap.release()
    cv2.destroyAllWindows()