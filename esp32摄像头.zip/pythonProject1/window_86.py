#coding

import cv2

def show_video_stream(url):
    # 创建一个VideoCapture对象来读取视频流
    cap = cv2.VideoCapture(url)

    if not cap.isOpened():
        print("无法打开视频流")
        return

    while True:
        # 读取一帧
        ret, frame = cap.read()

        # 如果成功读取到帧（ret为True）
        if ret:
            # 显示帧
            cv2.imshow('86', frame)

            # 按'q'键退出
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            print("读取视频流时出错")

    # 释放VideoCapture资源并关闭所有窗口
    cap.release()
    cv2.destroyAllWindows()

# 调用函数显示视频流
show_video_stream('http://192.168.181.86:81/stream')