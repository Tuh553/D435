# coding:utf-8

import cv2
import numpy as np

# 视频流地址
stream_url_1 = 'http://192.168.181.101:81/stream'
stream_url_2 = 'http://192.168.181.20:81/stream'
# stream_url_3 = 'http://192.168.130.101:81/stream'
# 初始化VideoCapture对象
cap_1 = cv2.VideoCapture(stream_url_1)
cap_2 = cv2.VideoCapture(stream_url_2)
# cap_3 = cv2.VideoCapture(stream_url_3)
# 获取视频流的第一帧以获取视频的宽度和高度
_, frame_1 = cap_1.read()
frame_height, frame_width = frame_1.shape[:2]
frame_height = frame_height*2
frame_width = frame_width*2

# 设置字体及字体大小
font = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 0.5
text_color = (255, 255, 255)  # 白色
thickness = 2
line_type = cv2.LINE_AA

while True:
    # 读取最新的一帧
    ret_1, frame_1 = cap_1.read()
    ret_2, frame_2 = cap_2.read()
    # ret_3, frame_3 = cap_3.read()
    # frame_1 = cv2.resize(frame_1, (640,480))
    # frame_2 = cv2.resize(frame_2, (640,480))
    # frame_3 = cv2.resize(frame_3, (640,480))
    if ret_1:
        # 计算文字在底部中央的位置
        text_top_left_corner = (int((frame_width - 100) / 2), int(frame_height - 50))

        # 在帧上绘制文字
        cv2.putText(frame_1, "right", text_top_left_corner, font, font_scale, text_color, thickness, line_type)
    else:
        frame_1 = np.zeros((frame_width,frame_height))
    if ret_2:
        text_top_left_corner = (int((frame_width - 100) / 2), int(frame_height - 50))

        #在帧上绘制文字
        cv2.putText(frame_2,"left", text_top_left_corner,font,font_scale,text_color,thickness,line_type)
    else:
        frame_2 = np.zeros((320, 240, 3))

    # if ret_3:
    #     text_top_left_corner = (int((frame_width - 100) / 2), int(frame_height - 50))
    #     cv2.putText(frame_3,"left", text_top_left_corner,font,font_scale,text_color,thickness,line_type)
    # else:
    #     frame_3 = np.zeros((640, 480, 3))
    frame_4 = np.zeros((240, 320, 3),dtype=np.uint8)
    text_top_left_corner = (int((frame_width - 100) / 2), int(frame_height - 50))
    cv2.putText(frame_4, "back", text_top_left_corner, font, font_scale, text_color, thickness, line_type)
    # frame_total_1 = np.hstack((frame_2, frame_4))
    # frame_total_2 = np.hstack((frame_3, frame_1))
    try:
        frame_total_1 = np.hstack((frame_1, frame_2))
    except:
        frame_total_1 = np.zeros((frame_width,frame_height))
    # frame_total = np.vstack((frame_total_1, frame_total_2))

    print(frame_height)
    print(frame_width)

    # 显示带有文字的视频帧
    cv2.imshow('live', frame_total_1)


    # 检查按键事件，'q' 键退出循环
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 清理资源
cap_1.release()
cv2.destroyAllWindows()